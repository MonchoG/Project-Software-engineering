
import java.math.BigInteger;
import java.sql.Array;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.CancellationException;
import java.util.zip.Inflater;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;

import static jdk.nashorn.internal.objects.Global.Infinity;


public class GraphsController{

    private Scene scene1;
    private AppMain main;
    @FXML
    private NumberAxis xAxis;
    @FXML
    private LineChart<Integer, Double> lineChart;
    @FXML
    private ToggleButton temp;
    @FXML
    private ToggleButton light;
    @FXML
    private ToggleButton pres;
    @FXML
    private ToggleButton humid;
    @FXML
    private ToggleButton rangeDay;
    @FXML
    private ToggleButton rangeWeek;
    @FXML
    private ToggleButton rangeMonth;
    private int index;
    private PopupController pc = new PopupController();
    private DAO dbc = new DAO(DBmanager.getInstance());
    //Getting all arrayLists
    private double[] temperatureDay = new double[25];
    private double[] temperatureWeek = new double[8];
    private double[] temperatureMonth = new double[32];
    private ArrayList<Double> temperatureCustom = new ArrayList<>();
    private double[] lightDay = new double[25];
    private double[] lightWeek = new double[8];
    private double[] lightMonth = new double[32];
    private ArrayList<Double> lightCustom = new ArrayList<>();
    private double[] presDay = new double[25];
    private double[] presWeek = new double[8];
    private double[] presMonth = new double[32];
    private ArrayList<Double> presCustom = new ArrayList<>();
    private double[] humidDay = new double[25];
    private double[] humidWeek = new double[8];
    private double[] humidMonth = new double[32];
    private ArrayList<Double> humidCustom = new ArrayList<>();
    private boolean customDate;
    private double NaN;

    /**
     * Setting default graph on Temperature
     * Setting Temperature ToggleButton on selected and the others on not selected
     */

    public void initialize(){
        rangeDay.setSelected(true);
        rangeDay.setDisable(true);

        //Temperature is default shown on graph
        temp.setSelected(true);
        light.setSelected(false);
        pres.setSelected(false);
        humid.setSelected(false);
        dataRange();


    }

    /**
     * Checking which variables are selected
     * Showing the selected values in a graph
     */

    public void setLineChart(){
        //Checking Temperature button
        if(temp.isSelected()){
            //Checking Light button
            if(light.isSelected()){
                //Checking Pressure button
                if(pres.isSelected()){
                    //Checking Humidity button
                    if(humid.isSelected()){
                        //All four variables are selected
                        lineChart.getData().setAll(getTemp(), getLight(), getPres(), getHumid());
                    }
                    else{
                        //Temperature, Light and Pressure are selected
                        lineChart.getData().setAll(getTemp(), getLight(), getPres());
                    }
                }
                //Checking Humidity button
                else if(humid.isSelected()){
                    //Temperature, Light and Humidity are selected
                    lineChart.getData().setAll(getTemp(), getLight(), getHumid());
                }
                else{
                    //Temperature and Light are Selected
                    lineChart.getData().setAll(getTemp(), getLight());
                }
            }
            //Checking Pressure button
            else if(pres.isSelected()){
                //Checking Humidity button
                if(humid.isSelected()){
                    //Temperature, Pressure and Humidity are selected
                    lineChart.getData().setAll(getTemp(), getPres(), getHumid());
                }
                else{
                    //Temperature and Pressure are selected
                    lineChart.getData().setAll(getTemp(), getPres());
                }
            }
            else{
                //Checking Humidity button
                if(humid.isSelected()){
                    //Temperature and Humidity are selected
                    lineChart.getData().setAll(getTemp(), getHumid());
                }
                else{
                    //Only Temperature is selected
                    lineChart.getData().setAll(getTemp());
                }
            }
        }

        //Checking Light button
        else if(light.isSelected()){
            //Checking Pressure button
            if(pres.isSelected()){
                //Checking Humidity button
                if(humid.isSelected()){
                    //Light, Pressure and Humidity are selected
                    lineChart.getData().setAll(getLight(), getPres(), getHumid());
                }
                else{
                    //Light and Pressure are Selected
                    lineChart.getData().setAll(getLight(), getPres());
                }
            }
            else if(humid.isSelected()){
                //Light and Humidity are selected
                lineChart.getData().setAll(getLight(), getHumid());
            }
            else{
                //Only light is selected
                lineChart.getData().setAll(getLight());
            }
        }

        //Checking Pressure button
        else if(pres.isSelected()){
            //Checking Humidity button
            if(humid.isSelected()){
                //Pressure and Humidity are selected
                lineChart.getData().setAll(getPres(), getHumid());
            }
            else{
                //Only Pressure is selected
                lineChart.getData().setAll(getPres());
            }

        }
        //Checking Humidity button
        else if(humid.isSelected()){
            //Only Humidity is selected
            lineChart.getData().setAll(getHumid());
        }
        else{
            //None are selected
            lineChart.getData().setAll();
        }
    }

    /**
     * Creating XYChart
     * Adding all values in it
     * @return Light XYChart with all data in it
     */

    private XYChart.Series<Integer, Double> getLight() {
        //Creating graph for Light
        XYChart.Series<Integer, Double> light = new XYChart.Series<>();
        if (customDate) {
            for (int i = 0; i < lightCustom.size(); i++) {
                index = dbc.getBeginDay();
                light.getData().add(new XYChart.Data<>(index + i, lightCustom.get(i)));
            }
        } else if (rangeDay.isSelected()) {
            int count = 0;
            for (int i = lightDay.length - 1; i >= 0; i--) {
                /*if(lightDay[i] == null){
                    light.getData().add(new XYChart.Data<>(count++, (lightDay[(i-1)]+lightDay[(i+1)])/2));
                }else*/ {
                    light.getData().add(new XYChart.Data<>(count++, lightDay[i]));
                }
            }

        } else if (rangeWeek.isSelected()) {
            int count = 0;
            for (int i = lightWeek.length - 1; i >= 0; i--) {
                light.getData().add(new XYChart.Data<>(count, lightWeek[i]));
                count++;
            }
        } else if (rangeMonth.isSelected()) {
            int count = 0;
            for (int i = lightMonth.length - 1; i >= 0; i--) {
                light.getData().add(new XYChart.Data<>(count, lightMonth[i]));
                count++;
            }
        }
        //Setting Legend name
        light.setName("Light (lx)");

        return light;
    }

    /**
     * Creating a XYChart
     * Adding all values in it
     * @return Temperature XYChart with all data in it
     */

    private XYChart.Series<Integer, Double> getTemp() {
        //Creating graph for Temp
        XYChart.Series<Integer, Double> temp = new XYChart.Series<>();
        if (customDate) {
            for (int i = 0; i < temperatureCustom.size(); i++) {
                index = dbc.getBeginDay();
                temp.getData().add(new XYChart.Data<>(index + i, temperatureCustom.get(i)));
            }
        } else if (rangeDay.isSelected()) {
            int count = 0;
            for (int i = (temperatureDay.length-1); i >= 0; i--) {
                int j = i;
                if(temperatureDay[j] == -Infinity){
                    while(temperatureDay[j-1] == -Infinity){
                        j--;
                        if(j == 0){
                            break;
                        }
                    }
                    double temp1;
                    if(j == 0){
                        temp1 = 0;

                    }else {
                        temp1 = temperatureDay[j];
                    }
                    while(temperatureDay[j] == -Infinity){
                        if(j == 24){
                            break;
                        }
                        j++;
                    }
                    double temp2;
                    if(j == 24){
                        temp2 = 0;
                        temp.getData().add(new XYChart.Data<>(count++, temp1));
                    }else {
                        temp2 = temperatureDay[j];
                        if(temp1 == 0){
                            temp.getData().add(new XYChart.Data<>(count++, temp2));
                        }else{
                            if(temp2 == 0){
                                temp.getData().add(new XYChart.Data<>(count++, temp1));
                            }else{
                                temp.getData().add(new XYChart.Data<>(count++, (temp1+temp2)/2));
                            }
                        }
                    }

                }else {
                    temp.getData().add(new XYChart.Data<>(count++, temperatureDay[i]));
                }

            }
        } else if (rangeWeek.isSelected()) {
            int count = 0;
            for (int i = temperatureWeek.length - 1; i >= 0; i--) {
                temp.getData().add(new XYChart.Data<>(count, temperatureWeek[i]));
                count++;
            }
        } else if (rangeMonth.isSelected()) {
            int count = 0;
            for (int i = temperatureMonth.length - 1; i >= 0; i--) {
                temp.getData().add(new XYChart.Data<>(count, temperatureMonth[i]));
                count++;
            }
        }

            //Setting Legend name
            temp.setName("Temp (°C)");
            return temp;
        /**
         * Creating a XYChart
         * Adding all values into the graph
         * @return Pressure XYChart with all data in it
         */
    }
    private XYChart.Series<Integer, Double> getPres() {
            //Creating graph for Pressure
            XYChart.Series<Integer, Double> pres = new XYChart.Series<>();
            if (customDate) {
                for (int i = 0; i < presCustom.size(); i++) {
                    index = dbc.getBeginDay();
                    pres.getData().add(new XYChart.Data<>(index + i, presCustom.get(i)));
                }
            } else if (rangeDay.isSelected()) {
                int count = 0;
                for (int i = presDay.length - 1; i >= 0; i--) {
                    int j = i;
                    /*if(presDay[i] == null){
                        System.out.println("test");
                        while(presDay.get(j) == null){
                            j--;
                        }
                        double temp2 = presDay.get(i);
                        while(presDay.get(i) == null){
                            j++;
                        }
                        double temp1 = presDay.get(i);

                        pres.getData().add(new XYChart.Data<>(count, (temp1+temp2)/2));
                    }else*/ {
                        pres.getData().add(new XYChart.Data<>(count++, presDay[i]));
                    }
                }
            } else if (rangeWeek.isSelected()) {
                int count = 0;
                for (int i = presWeek.length - 1; i >= 0; i--) {
                    pres.getData().add(new XYChart.Data<>(count, presWeek[i]));
                    count++;
                }
            } else if (rangeMonth.isSelected()) {
                int count = 0;
                for (int i = presMonth.length - 1; i >= 0; i--) {
                    pres.getData().add(new XYChart.Data<>(count, presMonth[i]));
                    count++;
                }
            }
            //Setting Legend name
            pres.setName("Pressure (atm)");

            return pres;
    }

    /**
     * Creating a XYChart
     * Adding all values into the graph
     * @return Humidity XYChart with all data in it
     */

    private XYChart.Series<Integer, Double> getHumid() {
            //Creating graph for Pressure


            XYChart.Series<Integer, Double> humid = new XYChart.Series<>();
            if (customDate) {
                for (int i = 0; i < humidCustom.size(); i++) {
                    index = dbc.getBeginDay();
                    humid.getData().add(new XYChart.Data<>(index + i, humidCustom.get(i)));
                }
            } else if (rangeDay.isSelected()) {
                int count = 0;
                for (int i = humidDay.length - 1; i >= 0; i--) {
                    int j = i;
                    if(humidDay[i] == -Infinity){
                        System.out.println("test");
                        while(humidDay[j] == -Infinity){
                            j--;
                        }
                        double temp2 = humidDay[j];
                        while(humidDay[i] == -Infinity){
                            j++;
                        }
                        double temp1 = humidDay[j];

                        humid.getData().add(new XYChart.Data<>(count, (temp1+temp2)/2));
                    }else {
                        humid.getData().add(new XYChart.Data<>(count, humidDay[i]));
                    }
                    count++;
                }
            } else if (rangeWeek.isSelected()) {
                int count = 0;
                for (int i = humidWeek.length - 1; i >= 0; i--) {
                    humid.getData().add(new XYChart.Data<>(count, humidWeek[i]));
                    count++;
                }
            } else if (rangeMonth.isSelected()) {
                int count = 0;
                for (int i = humidMonth.length - 1; i >= 0; i--) {
                    humid.getData().add(new XYChart.Data<>(count, humidMonth[i]));
                    count++;
                }
            }
            //Setting Legend name
            humid.setName("Humidity (%)");
            return humid;
    }

    /**dataRange
     * initializes ToggleGroup and adds rangeDay, rangeWeek, rangeMonth to it,
     * sets action listeners for these buttons
     */
    @FXML
    private void dataRange(){
        ToggleGroup group=new ToggleGroup();
        rangeDay.setToggleGroup(group);
        rangeWeek.setToggleGroup(group);
        rangeMonth.setToggleGroup(group);
        xAxis.setTickLabelsVisible(false);
        if(rangeDay.isSelected()){
            temperatureDay=dbc.getDay("temperature");
            //lightDay = dbc.getDay("light");
            //presDay=dbc.getDay("pressure");
            //humidDay=dbc.getDay("humidity");
            xAxis.setLowerBound(0);
            xAxis.setUpperBound(24);
            xAxis.setLabel("Hours ago");
            rangeDay.setDisable(true);
            rangeWeek.setDisable(false);
            rangeWeek.setSelected(false);
            rangeMonth.setDisable(false);
            rangeMonth.setSelected(false);
            customDate = false;
            setLineChart();
        };
        if(rangeWeek.isSelected()){
            temperatureWeek=dbc.getWeek("temperature");
            lightWeek=dbc.getWeek("light");
            presWeek=dbc.getWeek("pressure");
            humidWeek=dbc.getWeek("humidity");
            xAxis.setLowerBound(0);
            xAxis.setUpperBound(7);
            xAxis.setLabel("Days ago");
            rangeDay.setDisable(false);
            rangeDay.setSelected(false);
            rangeWeek.setDisable(true);
            rangeMonth.setDisable(false);
            rangeMonth.setSelected(false);
            customDate=false;
            setLineChart();
        };
        if(rangeMonth.isSelected()){
            temperatureMonth=dbc.getMonth("temperature");
            lightMonth=dbc.getMonth("light");
            presMonth=dbc.getMonth("pressure");
            humidMonth=dbc.getMonth("humidity");
            xAxis.setLowerBound(0);
            xAxis.setUpperBound(30);
            xAxis.setLabel("Days ago");
            rangeDay.setDisable(false);
            rangeDay.setSelected(false);
            rangeWeek.setDisable(false);
            rangeWeek.setSelected(false);
            rangeMonth.setDisable(true);
            customDate=false;
            setLineChart();
        };

    }

    /**
     * customDate
     * initializes PopupController class and calls display method
     */

    @FXML
    private void customDate() {
        dbc.custom();
        if(dbc.getBeginDate().charAt(0) != 'n' && dbc.getEndDate().charAt(0) != 'n' ) {
            index = pc.getBeginDay();
            customDate = true;

            temperatureCustom = dbc.getCustom("temperature");
            presCustom = dbc.getCustom("pressure");
            lightCustom = dbc.getCustom("light");
            humidCustom = dbc.getCustom("humidity");

            rangeDay.setDisable(false);
            rangeDay.setSelected(false);
            rangeWeek.setDisable(false);
            rangeWeek.setSelected(false);
            rangeMonth.setDisable(false);
            rangeMonth.setSelected(false);
            double begin = Double.parseDouble(dbc.getBeginDate().substring(8, 10));
            double end = Double.parseDouble(dbc.getEndDate().substring(8, 10));
            xAxis.setLowerBound(begin);
            xAxis.setUpperBound(end);
            int month = Integer.parseInt(dbc.getBeginDate().substring(5, 7));
            String monthString;
            switch (month){
                case 1: monthString = "January";
                        break;
                case 2: monthString = "February";
                    break;
                case 3: monthString = "March";
                    break;
                case 4: monthString = "April";
                    break;
                case 5: monthString = "May";
                    break;
                case 6: monthString = "June";
                    break;
                case 7: monthString = "July";
                    break;
                case 8: monthString = "August";
                    break;
                case 9: monthString = "September";
                    break;
                case 10: monthString = "October";
                    break;
                case 11: monthString = "November";
                    break;
                case 12: monthString = "December";
                    break;
                default: monthString = "Days";
                    break;
            }
            xAxis.setLabel(monthString);
            xAxis.setTickLabelsVisible(true);
            setLineChart();
        }else{
            System.out.println("Invalid value has been entered");
        }


    }

    public void setMain(AppMain main){
        this.main = main;
    }
    public void setScene1(Scene scene1){
        this.scene1 = scene1;
    }
    @FXML
    public void pressButton2() {
        main.setScene(scene1);
    }
}
